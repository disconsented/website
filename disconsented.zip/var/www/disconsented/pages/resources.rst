.. title: Resources
.. slug: resources
.. date: 2017-06-13 19:00:38 UTC+12:00
.. tags: 
.. category: 
.. link: 
.. description: 
.. type: text

Internal Resources
------------------

.. post-list::
   :categories: Resource
   :post_type: pages

**External Resources**
----------------------

- `Learn programming <http://sitwon.github.io/learnproglang/Home.html>`_
- `How to Ask a Smart Question <https://web.archive.org/web/20180107021115/http://faculty.gvc.edu/ssnyder/121/Goodquestions.html>`_
- `Freenode ##windows resources <http://www.freenode-windows.org/resources>`_
- `Megahertz myth <https://en.wikipedia.org/wiki/Megahertz_myth>`_
- `r/overclocking wiki <https://www.reddit.com/r/overclocking/wiki/index>`_
- `r/techsupport knowledgebase <https://rtechsupport.org/>`_
- `CPU Utilization is Wrong - Brendan Gregg <http://www.brendangregg.com/blog/2017-05-09/cpu-utilization-is-wrong.html>`_
