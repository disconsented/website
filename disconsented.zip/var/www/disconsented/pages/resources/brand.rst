.. title: Brand
.. slug: brand
.. date: 2015-08-20 12:59:10 UTC+12:00
.. tags: resource, guide, silly people
.. category: resource
.. link: 
.. description: Why using brand for comparison's is a bad idea 
.. type: text

Strictly speaking, brand hate/love is ridiculous.

Statistically speaking, you are judging the entire company based on having tested 0.0000001% of their products. 
In my experience, it is more likely that the problems you encountered were caused by user error and poor maintenance. 
You would have seen similar issues with any product by any manufacturer but it is human nature to seek a scape goat. 

Many consumers expect all the bells and whistles but don't want to pay for them, 
and so companies are forced to lower the build quality and choose cheaper components to be able to reach the customer's desired price point and remain profitable. 

In addition a brand may contain a range of products some of which maybe be sensible purchases whilst others less so. 
For example compare an AMD FX-9590 and an AMD FX-6300, the 9590 is a 220W flamethrower that cost roughly the same as an Intel i5-4690 but preforms worse in almost every benchmark. 
The 6300 on the other hand is a 95W part with a much lower price giving it a nice niche between products like Intel's Pentium G3258 and i3-4160.

TL;DR Brand + Electronics = Dumb

..

        N.B: Adapted from [#]_ 
        
        N.B: You may have been linked to this for saying a dumb thing..
        
        
        
        
.. [#]  http://rydian.net/tools/cps/view/brand.txt

