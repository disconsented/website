.. title: Video Resources
.. slug: video-resources
.. date: 2016-11-20 15:02:40 UTC+13:00
.. tags: video, resource
.. category: Resource
.. link: 
.. description: Collection of useful video resources
.. type: text

.. youtube:: YySa723VD2Y

.. youtube:: QG4LXw4Nd5U