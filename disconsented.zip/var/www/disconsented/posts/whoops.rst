.. title: Whoops!
.. slug: whoops
.. date: 2017-06-13 15:19:31 UTC+12:00
.. tags: 
.. category: 
.. link: 
.. description: What happened to this site.
.. type: text

Long story short, I accidentally destroyed a ton of data. As a result I am backing things up and have my VPS properly configured.