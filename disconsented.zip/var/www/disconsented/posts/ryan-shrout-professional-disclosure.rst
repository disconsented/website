.. title: Ryan Shrout professional disclosure
.. slug: ryan-shrout-professional-disclosure
.. date: 2018-01-28 09:44:53 UTC+13:00
.. tags: 
.. category: Archive
.. link: 
.. description: 
.. type: text

For the sake of archiving I am recording this here and must recommend that people stay away from Ryan Shrout failure to disclose his relationship in some articles originally from `/u/inappropriatecontext <https://www.reddit.com/r/hardware/comments/7tdm7k/pcpers_response_to_the_recent_ethical_concerns/?st=JCXQJEZL&sh=3821c2ba>`_


.. TEASER_END

----------------------------------------------------------------------

.. gist:: b0934cfbdf13c4b586076f57870871e3
