.. title: Video Editing on NVMe
.. slug: video-editing-on-nvme
.. date: 2018-06-25 14:24:18 UTC+12:00
.. tags: SSD
.. category: Educational
.. link: 
.. description: Linus Tech Tips is useful for once!
.. type: text

Recently (Jun 24, 2018) Linus Sebsation published a video where he shows the viewer a lot about his companies server infrastructure, reasonably late in the video he shows what kind of bandwidth they need for editing 8k video. Odly 
enough it is about 3Gb/s which is well within SATA 3's practical limit of 4.4Gb/s, its quite safe to put the myth that Video Editing is a workload that benefits from NVMe to rest.

.. media:: https://www.youtube.com/watch?v=eQED3tF8wuw&t=720s
