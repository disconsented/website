.. title: TehNut has become the offical 1.7.10 maintainer for ANSSRPG
.. slug: tehnut-has-become-the-offical-1710-maintainer-for-anssrpg
.. date: 2015-10-09 15:31:11 UTC+13:00
.. tags: ANSSRPG
.. category: Minecraft
.. link: 
.. description: 
.. type: text
.. previewimage: disconsented.png

`TehNut <https://github.com/TehNut>`_ has taken up the task of maintaining the 1.7.10 version of ANSSRPG, so you can badger him instead of me for builds :)
