.. title: A New Venture
.. slug: a-new-venture
.. date: 2020-12-27 19:35:18 UTC+13:00
.. tags: Business, Minecraft, SEO
.. category: Minecraft
.. link: 
.. description: Starting PixelPond.io
.. type: text

For the past few months I have been quietly working towards starting my own game server host/provider I've decided to name `PixelPond.io <https://pixelpond.io>`_, aiming to
provide Wicked Fast Hosting for Australia and New Zealanding. In the coming months I _may_ document my journey building the software  as well assembling the physical servers.

I'm just really trying to build some more backlinks to boost my SEO >_>
